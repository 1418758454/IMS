<template>
  <div class="research-performance">
    <!-- 页面标题 -->
    <div class="page-header">
      <h2 class="main-title">科研业绩</h2>
      <el-divider></el-divider>
    </div>

    <!-- 年度工作量汇总卡片 -->
    <el-card class="module-card annual-workload-card">
      <div class="module-header">
        <h3 class="module-title">年度工作量汇总</h3>
      </div>
      <el-table :data="yearWorkloadTableData" border class="summary-table" >
        <el-table-column label="年份" width="120" align="center">
          <template v-slot="scope">
            <el-select 
              v-model="scope.row.year" 
              placeholder="选择年份" 
              
              style="width: 100%;"
              @change="calculateTotalWorkload"
            >
              <el-option v-for="year in years" :key="year" :label="year" :value="year"></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="课题工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.subjectWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="论文工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.paperWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="论著工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.monographWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="获奖工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.awardWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="专利工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.patentWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="软著工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.softwareWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="总工作量" width="120" align="center">
          <template v-slot="scope">
            <span class="total-workload">{{ scope.row.totalWorkload.toFixed(2) }}</span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 课题模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">一、课题</h3>
      </div>
      <el-table :data="subjectTableData" border class="module-table" >
        <el-table-column label="课题" align="center" width="80">
          <template v-slot="scope">{{ scope.$index + 1 }}</template>
        </el-table-column>
        <el-table-column label="项目名称" prop="projectName">
          <template v-slot="scope">
            <el-input v-model="scope.row.projectName"  placeholder="请输入项目名称"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="课题类型" prop="subjectType">
          <template v-slot="scope">
            <el-select v-model="scope.row.subjectType"  placeholder="请选择" @change="calculateTotalWorkload">
              <el-option label="国家自然基金" value="国家自然基金"></el-option>
              <el-option label="省部级项目" value="省部级项目"></el-option>
              <el-option label="校级项目" value="校级项目"></el-option>
              <el-option label="横向项目" value="横向项目"></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="执行时间" prop="executeTime">
          <template v-slot="scope">
            <el-date-picker v-model="scope.row.executeTime" type="monthrange"  range-separator="至" start-placeholder="开始月份" end-placeholder="结束月份"></el-date-picker>
          </template>
        </el-table-column>
        <el-table-column label="排名" prop="rank" width="100">
          <template v-slot="scope">
            <!-- <el-input v-model="scope.row.rank"  type="number" placeholder="1" @input="calculateTotalWorkload"></el-input> -->
            <el-input v-model="scope.row.rank" ></el-input>
          </template>
        </el-table-column>
        <el-table-column label="系数" prop="coefficient" width="100">
          <template v-slot="scope">
            <!-- <el-select v-model="scope.row.coefficient"  placeholder="请选择" @change="calculateTotalWorkload">
              <el-option label="1.0" value="1.0"></el-option>
              <el-option label="0.8" value="0.8"></el-option>
              <el-option label="0.5" value="0.5"></el-option>
            </el-select> -->
            <el-input v-model="scope.row.coefficient"  ></el-input>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload" width="100">
          <template v-slot="scope">
            <span class="workload-value">{{ calculateSubjectWorkload(scope.row) }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ subjectTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 论文模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">二、论文</h3>
      </div>
      <el-table :data="paperTableData" border class="module-table" >
        <el-table-column label="论文" align="center" width="80">
          <template v-slot="scope">{{ scope.$index + 1 }}</template>
        </el-table-column>
        <el-table-column label="论文名称" prop="title">
          <template v-slot="scope">
            <el-input v-model="scope.row.title"  placeholder="请输入论文名称"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="出版刊物" prop="journal">
          <template v-slot="scope">
            <el-input v-model="scope.row.journal"  placeholder="请输入刊物名称"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="出版时间" prop="publishTime">
          <template v-slot="scope">
            <el-date-picker v-model="scope.row.publishTime"  type="date" format="yyyy-MM-dd"></el-date-picker>
          </template>
        </el-table-column>
        <el-table-column label="论文级别" prop="level">
          <template v-slot="scope">
            <el-select v-model="scope.row.level"  placeholder="请选择" @change="calculateTotalWorkload">
              <el-option label="SCI一区" value="SCI一区"></el-option>
              <el-option label="SCI二区" value="SCI二区"></el-option>
              <el-option label="核心期刊" value="核心期刊"></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope">
            <!-- <el-input v-model="scope.row.rank"  type="number" placeholder="1" @input="calculateTotalWorkload"></el-input> -->
            <el-input v-model="scope.row.rank" ></el-input>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope">
            <span class="workload-value">{{ calculatePaperWorkload(scope.row) }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ paperTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 论著模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">三、论著</h3>
      </div>
      <el-table :data="monographTableData" border class="module-table" >
        <el-table-column label="论著" align="center" width="80">
          <template v-slot="scope">{{ scope.$index + 1 }}</template>
        </el-table-column>
        <el-table-column label="论著名称" prop="title">
          <template v-slot="scope">
            <el-input v-model="scope.row.title"  placeholder="请输入论著名称"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="出版社" prop="publisher">
          <template v-slot="scope">
            <el-input v-model="scope.row.publisher"  placeholder="请输入出版社"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="出版时间" prop="publishTime">
          <template v-slot="scope">
            <el-date-picker v-model="scope.row.publishTime"  type="date" format="yyyy-MM-dd"></el-date-picker>
          </template>
        </el-table-column>
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope">
            <!-- <el-input v-model="scope.row.rank"  type="number" placeholder="1"></el-input> -->
            <el-input v-model="scope.row.rank" ></el-input>

          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope">
            <span class="workload-value">{{ calculateMonographWorkload(scope.row) }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ monographTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 获奖模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">四、获奖</h3>
      </div>
      <el-table :data="awardTableData" border class="module-table" >
        <el-table-column label="获奖" align="center" width="80">
          <template v-slot="scope">{{ scope.$index + 1 }}</template>
        </el-table-column>
        <el-table-column label="获奖名称" prop="name">
          <template v-slot="scope">
            <el-input v-model="scope.row.name"  placeholder="请输入获奖名称"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="颁奖单位" prop="organizer">
          <template v-slot="scope">
            <el-input v-model="scope.row.organizer"  placeholder="请输入颁奖单位"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="获奖时间" prop="awardTime">
          <template v-slot="scope">
            <el-date-picker v-model="scope.row.awardTime"  type="date" format="yyyy-MM-dd"></el-date-picker>
          </template>
        </el-table-column>
        <el-table-column label="奖励级别" prop="level">
          <template v-slot="scope">
            <el-select v-model="scope.row.level"  placeholder="请选择">
              <el-option label="国家级" value="国家级"></el-option>
              <el-option label="省部级" value="省部级"></el-option>
              <el-option label="校级" value="校级"></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope">
            <!-- <el-input v-model="scope.row.rank"  type="number" placeholder="1"></el-input> -->
            <el-input v-model="scope.row.rank" ></el-input>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope">
            <span class="workload-value">{{ calculateAwardWorkload(scope.row) }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ awardTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 专利模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">五、专利</h3>
      </div>
      <el-table :data="patentTableData" border class="module-table" >
        <el-table-column label="专利" align="center" width="80">
          <template v-slot="scope">{{ scope.$index + 1 }}</template>
        </el-table-column>
        <el-table-column label="专利名称" prop="name">
          <template v-slot="scope">
            <el-input v-model="scope.row.name"  placeholder="请输入专利名称"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="专利类型" prop="type">
          <template v-slot="scope">
            <el-select v-model="scope.row.type"  placeholder="请选择">
              <el-option label="发明专利" value="发明专利"></el-option>
              <el-option label="实用新型专利" value="实用新型专利"></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="申请时间" prop="applyTime">
          <template v-slot="scope">
            <el-date-picker v-model="scope.row.applyTime"  type="date" format="yyyy-MM-dd"></el-date-picker>
          </template>
        </el-table-column>
        <el-table-column label="授权时间" prop="authorizeTime">
          <template v-slot="scope">
            <el-date-picker v-model="scope.row.authorizeTime"  type="date" format="yyyy-MM-dd"></el-date-picker>
          </template>
        </el-table-column>
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope">
            <!-- <el-input v-model="scope.row.rank"  type="number" placeholder="1"></el-input> -->
            <el-input v-model="scope.row.rank" ></el-input>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope">
            <span class="workload-value">{{ calculatePatentWorkload(scope.row) }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ patentTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 软著模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">六、软著</h3>
      </div>
      <el-table :data="softwareTableData" border class="module-table" >
        <el-table-column label="软著" align="center" width="80">
          <template v-slot="scope">{{ scope.$index + 1 }}</template>
        </el-table-column>
        <el-table-column label="软著名称" prop="name">
          <template v-slot="scope">
            <el-input v-model="scope.row.name"  placeholder="请输入软著名称"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="申请时间" prop="applyTime">
          <template v-slot="scope">
            <el-date-picker v-model="scope.row.applyTime"  type="date" format="yyyy-MM-dd"></el-date-picker>
          </template>
        </el-table-column>
        <el-table-column label="授权时间" prop="authorizeTime">
          <template v-slot="scope">
            <el-date-picker v-model="scope.row.authorizeTime"  type="date" format="yyyy-MM-dd"></el-date-picker>
          </template>
        </el-table-column>
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope">
            <!-- <el-input v-model="scope.row.rank"  type="number" placeholder="1"></el-input> -->
            <el-input v-model="scope.row.rank" ></el-input>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope">
            <span class="workload-value">{{ calculateSoftwareWorkload(scope.row) }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ softwareTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 年份选择器数据
      years: [2021, 2022, 2023, 2024, 2025],
      // 年度工作量汇总数据
      yearWorkloadTableData: [{
        year: new Date().getFullYear(), // 默认当前年份
        subjectWorkload: 0,
        paperWorkload: 0,
        monographWorkload: 0,
        awardWorkload: 0,
        patentWorkload: 0,
        softwareWorkload: 0,
        totalWorkload: 0
      }],
      // 课题模块数据（10行）
      subjectTableData: Array.from({ length: 10 }, () =>({
        projectName: '',
        subjectType: '',
        executeTime: [],
        rank: '',
        coefficient: ''
      })),
      subjectTotalWorkload: 0,
      // 论文模块数据（10行）
      paperTableData: Array.from({ length: 10 }, () =>({
        title: '',
        journal: '',
        publishTime: '',
        level: '',
        rank: ''
      })),
      paperTotalWorkload: 0,
      // 论著模块数据（10行）
      monographTableData: Array.from({ length: 10 }, () =>({
        title: '',
        publisher: '',
        publishTime: '',
        rank: ''
      })),
      monographTotalWorkload: 0,
      // 获奖模块数据（5行）
      awardTableData: Array.from({ length: 10 }, () =>({
        name: '',
        organizer: '',
        awardTime: '',
        level: '',
        rank: ''
      })),
      awardTotalWorkload: 0,
      // 专利模块数据（10行）
      patentTableData: Array.from({ length: 10 }, () =>({
        name: '',
        type: '',
        applyTime: '',
        authorizeTime: '',
        rank: ''
      })),
      patentTotalWorkload: 0,
      // 软著模块数据（5行）
      softwareTableData: Array.from({ length: 10 }, () =>({
        name: '',
        applyTime: '',
        authorizeTime: '',
        rank: ''
      })),
      softwareTotalWorkload: 0
    };
  },
  mounted() {
    this.calculateTotalWorkload(); // 初始化计算工作量
  },
  methods: {
    // 计算课题工作量（基础分×系数÷排名）
    calculateSubjectWorkload(row) {
      const baseScore = {
        '国家自然基金': 100,
        '省部级项目': 80,
        '校级项目': 50,
        '横向项目': 60
      }[row.subjectType] || 0;
      const coefficient = Number(row.coefficient) || 1;
      const rank = Number(row.rank) || 1;
      return (baseScore * coefficient / rank).toFixed(2);
    },
    // 计算论文工作量（级别分÷排名）
    calculatePaperWorkload(row) {
      const levelScore = {
        'SCI一区': 150,
        'SCI二区': 100,
        '核心期刊': 60
      }[row.level] || 0;
      const rank = Number(row.rank) || 1;
      return (levelScore / rank).toFixed(2);
    },
    // 计算论著工作量（固定分÷排名）
    calculateMonographWorkload(row) {
      const baseScore = 80; // 论著基础分
      const rank = Number(row.rank) || 1;
      return (baseScore / rank).toFixed(2);
    },
    // 计算获奖工作量（级别分÷排名）
    calculateAwardWorkload(row) {
      const levelScore = {
        '国家级': 200,
        '省部级': 100,
        '校级': 50
      }[row.level] || 0;
      const rank = Number(row.rank) || 1;
      return (levelScore / rank).toFixed(2);
    },
    // 计算专利工作量（类型分÷排名）
    calculatePatentWorkload(row) {
      const typeScore = {
        '发明专利': 120,
        '实用新型专利': 50
      }[row.type] || 0;
      const rank = Number(row.rank) || 1;
      return (typeScore / rank).toFixed(2);
    },
    // 计算软著工作量（固定分÷排名）
    calculateSoftwareWorkload(row) {
      const baseScore = 40; // 软著基础分
      const rank = Number(row.rank) || 1;
      return (baseScore / rank).toFixed(2);
    },
    // 计算所有模块合计工作量并更新年度汇总
    calculateTotalWorkload() {
      // 计算各模块合计
      this.subjectTotalWorkload = this.subjectTableData.reduce((sum, row) => sum + Number(this.calculateSubjectWorkload(row)), 0);
      this.paperTotalWorkload = this.paperTableData.reduce((sum, row) => sum + Number(this.calculatePaperWorkload(row)), 0);
      this.monographTotalWorkload = this.monographTableData.reduce((sum, row) => sum + Number(this.calculateMonographWorkload(row)), 0);
      this.awardTotalWorkload = this.awardTableData.reduce((sum, row) => sum + Number(this.calculateAwardWorkload(row)), 0);
      this.patentTotalWorkload = this.patentTableData.reduce((sum, row) => sum + Number(this.calculatePatentWorkload(row)), 0);
      this.softwareTotalWorkload = this.softwareTableData.reduce((sum, row) => sum + Number(this.calculateSoftwareWorkload(row)), 0);

      // 更新年度汇总
      this.yearWorkloadTableData[0].subjectWorkload = this.subjectTotalWorkload;
      this.yearWorkloadTableData[0].paperWorkload = this.paperTotalWorkload;
      this.yearWorkloadTableData[0].monographWorkload = this.monographTotalWorkload;
      this.yearWorkloadTableData[0].awardWorkload = this.awardTotalWorkload;
      this.yearWorkloadTableData[0].patentWorkload = this.patentTotalWorkload;
      this.yearWorkloadTableData[0].softwareWorkload = this.softwareTotalWorkload;
      this.yearWorkloadTableData[0].totalWorkload = this.subjectTotalWorkload + this.paperTotalWorkload + this.monographTotalWorkload + this.awardTotalWorkload + this.patentTotalWorkload + this.softwareTotalWorkload;
    }
  }
};
</script>

<style scoped>
.research-performance {
  padding: 20px;
  background-color: #fafafa;
}
/* 页面标题样式 */
.page-header {
  margin-bottom: 30px;
}
.main-title {
  font-size: 24px;
  color: #1f2f3d;
  font-weight: 600;
  text-align: center;
  margin-bottom: 10px;
}
/* 模块卡片样式 */
.module-card {
  margin-bottom: 30px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  overflow: hidden;
}
/* 模块标题样式 */
.module-header {
  padding: 12px 20px;
  background-color: #f5f7fa;
  border-bottom: 1px solid #e6e6e6;
}
.module-title {
  font-size: 18px;
  color: #2c3e50;
  font-weight: 500;
  padding-left: 10px;
  border-left: 4px solid #409eff;
  margin: 0;
}
/* 表格样式 */
.module-table {
  width: 100%;
  font-size: 14px;
}
::v-deep .el-table th {
  background-color: #f0f2f5;
  color: #303133;
  font-weight: 500;
}
::v-deep .el-table__row:nth-child(even) {
  background-color: #fafafa;
}
::v-deep .el-table__row:hover {
  background-color: #f5f9ff;
}
::v-deep .el-table td {
  padding: 12px 8px;
}
/* 工作量数值样式 */
.workload-value {
  color: #2c6ecb;
  font-weight: 500;
}
/* 模块小计样式 */
.module-summary {
  text-align: right;
  padding: 12px 20px;
  font-size: 14px;
  color: #303133;
  border-top: 1px dashed #e6e6e6;
  background-color: #fafafa;
}
.summary-label {
  color: #606266;
}
.summary-value {
  font-weight: 500;
  color: #e67700;
  margin-left: 8px;
}
/* 年度汇总卡片样式 */
.annual-workload-card {
  border-top: 3px solid #409eff;
}
.summary-table {
  font-size: 14px;
}
.total-workload {
  font-size: 16px;
  font-weight: 600;
  color: #e67700;
}
/* 空值提示样式 */
.empty-tip {
  position: absolute;
  right: 15px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 12px;
  color: #909399;
  pointer-events: none;
}
/* 输入框/选择器聚焦样式 */
::v-deep .el-input__inner:focus,
::v-deep .el-select:focus-within .el-input__inner {
  border-color: #409eff;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.2);
}
</style>