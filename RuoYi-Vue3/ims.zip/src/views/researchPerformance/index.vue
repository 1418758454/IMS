<template>
  <div class="research-performance">
    <!-- 页面标题 -->
    <div class="page-header">
      <h2 class="main-title">科研业绩</h2>
      <el-divider></el-divider>
    </div>

    <!-- 年度工作量汇总卡片 -->
    <el-card class="module-card annual-workload-card">
      <div class="module-header">
        <h3 class="module-title">年度工作量汇总</h3>
      </div>
      <el-table :data="yearWorkloadTableData" border class="summary-table">
        <el-table-column label="年份" width="120" align="center">
          <template v-slot="scope">{{ scope.row.year }}</template>
        </el-table-column>
        <el-table-column label="课题工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.subjectWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="论文工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.paperWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="论著工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.monographWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="获奖工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.awardWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="专利工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.patentWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="软著工作量" width="120" align="center">
          <template v-slot="scope">{{ scope.row.softwareWorkload.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="总工作量" width="120" align="center">
          <template v-slot="scope">
            <span class="total-workload">{{ scope.row.totalWorkload.toFixed(2) }}</span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 一、课题模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">一、课题</h3>
        <div class="button-group" style="display: flex; gap: 5px;">  <!-- 关键：gap控制间距 -->
          <el-button type="primary" icon="Plus" @click="handleAdd('subject')" >新增</el-button>
          <el-button type="danger" icon="Delete" @click="handleDelete('subject')">删除</el-button>
        </div>
      </div>
      
      <el-table :data="subjectTableData" border class="module-table" ref="subjectTableRef" v-loading="loading.subject">
        <!-- 复选框列（第一列） -->
        <el-table-column type="selection" width="55" align="center"></el-table-column>

        <el-table-column label="课题" align="center" width="80">
          <template v-slot="scope">
            <!-- 结合分页参数计算连续序号 -->
            {{ (modulePagination.subject.currentPage - 1) * modulePagination.subject.pageSize + scope.$index + 1 }}
          </template>
        </el-table-column>
        <el-table-column label="项目名称" prop="projectName">
          <template v-slot="scope"><span>{{ scope.row.projectName }}</span></template>
        </el-table-column>
        <el-table-column label="课题类型" prop="subjectType">
          <template v-slot="scope"><span>{{ scope.row.subjectType }}</span></template>
        </el-table-column>
        <el-table-column label="执行时间">
          <template v-slot="scope">
            {{ scope.row.execute_time_start || '-' }} 至 {{ scope.row.execute_time_end || '-' }}
          </template>
        </el-table-column>
        
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope"><span>{{ scope.row.rank }}</span></template>
        </el-table-column>
        <el-table-column label="系数" prop="coefficient">
          <template v-slot="scope"><span>{{ scope.row.coefficient }}</span></template>
        </el-table-column>
        <!-- PDF列 -->
        <el-table-column label="PDF" align="center" width="100">
          <template v-slot="scope">
            <!-- 有PDF时显示查看链接，无则显示“无” -->
            <el-link 
              v-if="scope.row.pdfUrl" 
              type="primary" 
              icon="Document" 
              :href="scope.row.pdfUrl" 
              target="_blank"
            >
              查看
            </el-link>
            <span v-else>无</span>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope"><span class="workload-value">{{ scope.row.workload.toFixed(2) }}</span></template>
        </el-table-column>
      </el-table>

      <!-- 新增：分页控件 -->
      <div class="pagination-container" style="margin-top: 10px; text-align: right;">
        <el-pagination
          @size-change="(size) => handleSizeChange('subject', size)"  
          @current-change="(page) => handleCurrentChange('subject', page)"
          :current-page="modulePagination.subject.currentPage" 
          :page-sizes="[5, 10, 20, 50]"
          :page-size="modulePagination.subject.pageSize"  
          layout="total, sizes, prev, pager, next, jumper"
          :total="modulePagination.subject.total"> 
        </el-pagination>
      </div>

      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ subjectTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 二、论文模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">二、论文</h3>
        <div class="button-group" style="display: flex; gap: 5px;">  <!-- 关键：gap控制间距 -->
            <el-button type="primary" icon="Plus" @click="handleAdd('paper')" >新增</el-button>
            <el-button type="danger" icon="Delete" @click="handleDelete('paper')">删除</el-button>
        </div>
      </div>
      
      <el-table :data="paperTableData" border class="module-table" ref="paperTableRef">
        <!-- 复选框列（第一列） -->
        <el-table-column type="selection" width="55" align="center"></el-table-column>
        <el-table-column label="论文" align="center" width="80">
          <template v-slot="scope">
            <!-- 结合分页参数计算连续序号 -->
            {{ (modulePagination.paper.currentPage - 1) * modulePagination.paper.pageSize + scope.$index + 1 }}
          </template>
        </el-table-column>
        <el-table-column label="论文名称" prop="title">
          <template v-slot="scope"><span>{{ scope.row.title }}</span></template>
        </el-table-column>
        <el-table-column label="出版刊物" prop="journal">
          <template v-slot="scope"><span>{{ scope.row.journal }}</span></template>
        </el-table-column>
        <el-table-column label="出版时间" prop="publishTime">
          <template v-slot="scope"><span>{{ scope.row.publishTime }}</span></template>
        </el-table-column>
        <el-table-column label="论文级别" prop="level">
          <template v-slot="scope"><span>{{ scope.row.level }}</span></template>
        </el-table-column>
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope"><span>{{ scope.row.rank }}</span></template>
        </el-table-column>
        <!-- PDF列 -->
        <el-table-column label="PDF" align="center" width="100">
          <template v-slot="scope">
            <!-- 有PDF时显示查看链接，无则显示“无” -->
            <el-link 
              v-if="scope.row.pdfUrl" 
              type="primary" 
              icon="Document" 
              :href="scope.row.pdfUrl" 
              target="_blank"
            >
              查看
            </el-link>
            <span v-else>无</span>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope"><span class="workload-value">{{ scope.row.workload.toFixed(2) }}</span></template>
        </el-table-column>
      </el-table>

      <!-- 新增：分页控件 -->
      <div class="pagination-container" style="margin-top: 10px; text-align: right;">
        <el-pagination
          @size-change="(size) => handleSizeChange('paper', size)"  
          @current-change="(page) => handleCurrentChange('paper', page)"
          :current-page="modulePagination.paper.currentPage" 
          :page-sizes="[5, 10, 20, 50]"
          :page-size="modulePagination.paper.pageSize"  
          layout="total, sizes, prev, pager, next, jumper"
          :total="modulePagination.paper.total"> 
        </el-pagination>
      </div>

      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ paperTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 三、论著模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">三、论著</h3>
        <div class="button-group" style="display: flex; gap: 5px;">  <!-- 关键：gap控制间距 -->
          <el-button type="primary" icon="Plus" @click="handleAdd('monograph')" >新增</el-button>
          <el-button type="danger" icon="Delete" @click="handleDelete('monograph')">删除</el-button>
        </div>
      </div>
      
      <el-table :data="monographTableData" border class="module-table" ref="monographTableRef">
        <!-- 复选框列（第一列） -->
        <el-table-column type="selection" width="55" align="center"></el-table-column>

        <el-table-column label="论著" align="center" width="80">
          <template v-slot="scope">
            <!-- 结合分页参数计算连续序号 -->
            {{ (modulePagination.monograph.currentPage - 1) * modulePagination.monograph.pageSize + scope.$index + 1 }}
          </template>
        </el-table-column>
        <el-table-column label="论著名称" prop="title">
          <template v-slot="scope"><span>{{ scope.row.title }}</span></template>
        </el-table-column>
        <el-table-column label="出版社" prop="publisher">
          <template v-slot="scope"><span>{{ scope.row.publisher }}</span></template>
        </el-table-column>
        <el-table-column label="出版时间" prop="publishTime">
          <template v-slot="scope"><span>{{ scope.row.publishTime }}</span></template>
        </el-table-column>
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope"><span>{{ scope.row.rank }}</span></template>
        </el-table-column>
        <!-- PDF列 -->
        <el-table-column label="PDF" align="center" width="100">
          <template v-slot="scope">
            <!-- 有PDF时显示查看链接，无则显示“无” -->
            <el-link 
              v-if="scope.row.pdfUrl" 
              type="primary" 
              icon="Document" 
              :href="scope.row.pdfUrl" 
              target="_blank"
            >
              查看
            </el-link>
            <span v-else>无</span>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope"><span class="workload-value">{{ scope.row.workload.toFixed(2) }}</span></template>
        </el-table-column>
      </el-table>
      <!-- 新增：分页控件 -->
      <div class="pagination-container" style="margin-top: 10px; text-align: right;">
        <el-pagination
          @size-change="(size) => handleSizeChange('monograph', size)"  
          @current-change="(page) => handleCurrentChange('monograph', page)"
          :current-page="modulePagination.monograph.currentPage" 
          :page-sizes="[5, 10, 20, 50]"
          :page-size="modulePagination.monograph.pageSize"  
          layout="total, sizes, prev, pager, next, jumper"
          :total="modulePagination.monograph.total"> 
        </el-pagination>
      </div>
      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ monographTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 四、获奖模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">四、获奖</h3>
        <div class="button-group" style="display: flex; gap: 5px;">  <!-- 关键：gap控制间距 -->
          <el-button type="primary" icon="Plus" @click="handleAdd('award')" >新增</el-button>
          <el-button type="danger" icon="Delete" @click="handleDelete('award')">删除</el-button>
        </div>
      </div>
      
      <el-table :data="awardTableData" border class="module-table" ref="awardTableRef">
        <!-- 复选框列（第一列） -->
        <el-table-column type="selection" width="55" align="center"></el-table-column>

        <el-table-column label="获奖" align="center" width="80">
          <template v-slot="scope">
            <!-- 结合分页参数计算连续序号 -->
            {{ (modulePagination.award.currentPage - 1) * modulePagination.award.pageSize + scope.$index + 1 }}
          </template>
        </el-table-column>
        <el-table-column label="获奖名称" prop="name">
          <template v-slot="scope"><span>{{ scope.row.name }}</span></template>
        </el-table-column>
        <el-table-column label="颁奖单位" prop="organizer">
          <template v-slot="scope"><span>{{ scope.row.organizer }}</span></template>
        </el-table-column>
        <el-table-column label="获奖时间" prop="awardTime">
          <template v-slot="scope"><span>{{ scope.row.awardTime }}</span></template>
        </el-table-column>
        <el-table-column label="奖励级别" prop="level">
          <template v-slot="scope"><span>{{ scope.row.level }}</span></template>
        </el-table-column>
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope"><span>{{ scope.row.rank }}</span></template>
        </el-table-column>
        <!-- PDF列 -->
        <el-table-column label="PDF" align="center" width="100">
          <template v-slot="scope">
            <!-- 有PDF时显示查看链接，无则显示“无” -->
            <el-link 
              v-if="scope.row.pdfUrl" 
              type="primary" 
              icon="Document" 
              :href="scope.row.pdfUrl" 
              target="_blank"
            >
              查看
            </el-link>
            <span v-else>无</span>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope"><span class="workload-value">{{ scope.row.workload.toFixed(2) }}</span></template>
        </el-table-column>
      </el-table>
      <!-- 新增：分页控件 -->
      <div class="pagination-container" style="margin-top: 10px; text-align: right;">
        <el-pagination
          @size-change="(size) => handleSizeChange('award', size)"  
          @current-change="(page) => handleCurrentChange('award', page)"
          :current-page="modulePagination.award.currentPage" 
          :page-sizes="[5, 10, 20, 50]"
          :page-size="modulePagination.award.pageSize"  
          layout="total, sizes, prev, pager, next, jumper"
          :total="modulePagination.award.total"> 
        </el-pagination>
      </div>
      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ awardTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 五、专利模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">五、专利</h3>
        <div class="button-group" style="display: flex; gap: 5px;">  <!-- 关键：gap控制间距 -->
          <el-button type="primary" icon="Plus" @click="handleAdd('patent')" >新增</el-button>
          <el-button type="danger" icon="Delete" @click="handleDelete('patent')">删除</el-button>
        </div>
      </div>
      
      <el-table :data="patentTableData" border class="module-table" ref="patentTableRef">
        <!-- 复选框列（第一列） -->
        <el-table-column type="selection" width="55" align="center"></el-table-column>

        <el-table-column label="专利" align="center" width="80">
          <template v-slot="scope">
            <!-- 结合分页参数计算连续序号 -->
            {{ (modulePagination.patent.currentPage - 1) * modulePagination.patent.pageSize + scope.$index + 1 }}
          </template>
        </el-table-column>
        <el-table-column label="专利名称" prop="name">
          <template v-slot="scope"><span>{{ scope.row.name }}</span></template>
        </el-table-column>
        <el-table-column label="专利类型" prop="type">
          <template v-slot="scope"><span>{{ scope.row.type }}</span></template>
        </el-table-column>
        <el-table-column label="申请时间" prop="applyTime">
          <template v-slot="scope"><span>{{ scope.row.applyTime }}</span></template>
        </el-table-column>
        <el-table-column label="授权时间" prop="authorizeTime">
          <template v-slot="scope"><span>{{ scope.row.authorizeTime }}</span></template>
        </el-table-column>
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope"><span>{{ scope.row.rank }}</span></template>
        </el-table-column>
        <!-- PDF列 -->
        <el-table-column label="PDF" align="center" width="100">
          <template v-slot="scope">
            <!-- 有PDF时显示查看链接，无则显示“无” -->
            <el-link 
              v-if="scope.row.pdfUrl" 
              type="primary" 
              icon="Document" 
              :href="scope.row.pdfUrl" 
              target="_blank"
            >
              查看
            </el-link>
            <span v-else>无</span>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope"><span class="workload-value">{{ scope.row.workload.toFixed(2) }}</span></template>
        </el-table-column>
      </el-table>
      <!-- 新增：分页控件 -->
      <div class="pagination-container" style="margin-top: 10px; text-align: right;">
        <el-pagination
          @size-change="(size) => handleSizeChange('patent', size)"  
          @current-change="(page) => handleCurrentChange('patent', page)"
          :current-page="modulePagination.patent.currentPage" 
          :page-sizes="[5, 10, 20, 50]"
          :page-size="modulePagination.patent.pageSize"  
          layout="total, sizes, prev, pager, next, jumper"
          :total="modulePagination.patent.total"> 
        </el-pagination>
      </div>
      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ patentTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 六、软著模块 -->
    <el-card class="module-card">
      <div class="module-header">
        <h3 class="module-title">六、软著</h3>
      <div class="button-group" style="display: flex; gap: 5px;">  <!-- 关键：gap控制间距 -->
          <el-button type="primary" icon="Plus" @click="handleAdd('software')" >新增</el-button>
          <el-button type="danger" icon="Delete" @click="handleDelete('software')">删除</el-button>
        </div>
      </div>
      
      <el-table :data="softwareTableData" border class="module-table" ref="softwareTableRef">
        <!-- 复选框列（第一列） -->
        <el-table-column type="selection" width="55" align="center"></el-table-column>

        <el-table-column label="软著" align="center" width="80">
          <template v-slot="scope">
            <!-- 结合分页参数计算连续序号 -->
            {{ (modulePagination.software.currentPage - 1) * modulePagination.software.pageSize + scope.$index + 1 }}
          </template>
        </el-table-column>
        <el-table-column label="软著名称" prop="name">
          <template v-slot="scope"><span>{{ scope.row.name }}</span></template>
        </el-table-column>
        <el-table-column label="申请时间" prop="applyTime">
          <template v-slot="scope"><span>{{ scope.row.applyTime }}</span></template>
        </el-table-column>
        <el-table-column label="授权时间" prop="authorizeTime">
          <template v-slot="scope"><span>{{ scope.row.authorizeTime }}</span></template>
        </el-table-column>
        <el-table-column label="排名" prop="rank">
          <template v-slot="scope"><span>{{ scope.row.rank }}</span></template>
        </el-table-column>
        <!-- PDF列 -->
        <el-table-column label="PDF" align="center" width="100">
          <template v-slot="scope">
            <!-- 有PDF时显示查看链接，无则显示“无” -->
            <el-link 
              v-if="scope.row.pdfUrl" 
              type="primary" 
              icon="Document" 
              :href="scope.row.pdfUrl" 
              target="_blank"
            >
              查看
            </el-link>
            <span v-else>无</span>
          </template>
        </el-table-column>
        <el-table-column label="工作量" prop="workload">
          <template v-slot="scope"><span class="workload-value">{{ scope.row.workload.toFixed(2) }}</span></template>
        </el-table-column>
      </el-table>
      <!-- 新增：分页控件 -->
      <div class="pagination-container" style="margin-top: 10px; text-align: right;">
        <el-pagination
          @size-change="(size) => handleSizeChange('software', size)"  
          @current-change="(page) => handleCurrentChange('software', page)"
          :current-page="modulePagination.software.currentPage" 
          :page-sizes="[5, 10, 20, 50]"
          :page-size="modulePagination.software.pageSize"  
          layout="total, sizes, prev, pager, next, jumper"
          :total="modulePagination.software.total"> 
        </el-pagination>
      </div>
      <div class="module-summary">
        <span class="summary-label">模块合计：</span>
        <span class="summary-value">{{ softwareTotalWorkload.toFixed(2) }} 工作量</span>
      </div>
    </el-card>

    <!-- 新增：通用新增弹窗 -->
    <el-dialog 
        :title="dialogTitle" 
        v-model="dialogVisible"
        width="1000px" 
        :close-on-click-modal="false"
        :style="{ 
          top: '40%', 
          transform: 'translateY(-50%)', 
          marginTop: '0' 
  }"
    >
      <el-form 
        :model="formData" 
        :rules="formRules[currentModule]" 
        ref="addFormRef" 
        label-width="120px"
      >
        <!-- 课题模块表单 -->
        <template v-if="currentModule === 'subject'">
          <el-form-item label="项目名称" prop="projectName">
            <el-input v-model="formData.projectName" placeholder="请输入项目名称"></el-input>
          </el-form-item>
          <el-form-item label="课题类型" prop="subjectType">
            <el-select v-model="formData.subjectType" placeholder="请选择">
              <el-option label="国家自然基金" value="国家自然基金"></el-option>
              <el-option label="省部级项目" value="省部级项目"></el-option>
              <el-option label="校级项目" value="校级项目"></el-option>
              <el-option label="横向项目" value="横向项目"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="执行时间" prop="executeTime">
            <el-date-picker 
              v-model="formData.executeTime" 
              type="daterange" 
              range-separator="至" 
              start-placeholder="开始月份" 
              end-placeholder="结束月份"
              format="YYYY-MM-DD" 
              value-format="YYYY-MM-DD"
            ></el-date-picker>
          </el-form-item>
          <el-form-item label="排名" prop="rank">
            <el-input v-model.number="formData.rank" placeholder="请输入排名"></el-input>
          </el-form-item>
          <el-form-item label="系数" prop="coefficient">
            <el-select v-model="formData.coefficient" placeholder="请选择">
              <el-option label="1.0" value="1.0"></el-option>
              <el-option label="0.8" value="0.8"></el-option>
              <el-option label="0.5" value="0.5"></el-option>
            </el-select>
          </el-form-item>
          <!-- PDF上传 -->
          <el-form-item label="PDF上传" prop="pdfUrl">
            <el-upload
              class="upload-pdf"
              action="http://localhost:8080/api/system/upload" 
              :headers="uploadHeaders" 
              :on-success="handlePdfUpload"
              :before-upload="beforePdfUpload"
              :on-error="handleUploadError"
              accept=".pdf"
              :auto-upload="true"
              :show-file-list="false"
            >
              <el-button type="primary" :icon="Upload">选择PDF文件</el-button>
            </el-upload>
            <!-- 已上传文件显示区域 -->
            <div v-if="formData.pdfUrl" class="uploaded-file">
              <el-icon><Document /></el-icon>
              <span>{{ formData.pdfUrl.split('/').pop() }}</span>
              <el-button type="text" :icon="Close" @click="formData.pdfUrl = ''"></el-button>
            </div>
          </el-form-item>
          
        </template>
 
        <!-- 论文模块表单 -->
        <template v-if="currentModule === 'paper'">
          <el-form-item label="论文名称" prop="title">
            <el-input v-model="formData.title" placeholder="请输入论文名称"></el-input>
          </el-form-item>
          <el-form-item label="出版刊物" prop="journal">
            <el-input v-model="formData.journal" placeholder="请输入刊物名称"></el-input>
          </el-form-item>
          <el-form-item label="出版时间" prop="publishTime">
            <el-date-picker v-model="formData.publishTime" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD"></el-date-picker>
          </el-form-item>
          <el-form-item label="论文级别" prop="level">
            <el-select v-model="formData.level" placeholder="请选择">
              <el-option label="SCI一区" value="SCI一区"></el-option>
              <el-option label="SCI二区" value="SCI二区"></el-option>
              <el-option label="核心期刊" value="核心期刊"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="排名" prop="rank">
            <el-input v-model.number="formData.rank" placeholder="请输入排名"></el-input>
          </el-form-item>
          <!-- PDF上传 -->
          <el-form-item label="PDF上传" prop="pdfFile">
            <el-upload
              class="upload-pdf"
              action="/api/system/upload"  
              :on-success="handlePdfUpload"  
              :before-upload="beforePdfUpload"  
              accept=".pdf"   
              :auto-upload="true" 
            >
              <el-button type="primary" icon="Upload">选择PDF文件</el-button>
            </el-upload>
          </el-form-item>
        </template>

        <!-- 论著模块表单 -->
        <template v-if="currentModule === 'monograph'">
          <el-form-item label="论著名称" prop="title">
            <el-input v-model="formData.title" placeholder="请输入论著名称"></el-input>
          </el-form-item>
          <el-form-item label="出版社" prop="publisher">
            <el-input v-model="formData.publisher" placeholder="请输入出版社"></el-input>
          </el-form-item>
          <el-form-item label="出版时间" prop="publishTime">
            <el-date-picker v-model="formData.publishTime" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD"></el-date-picker>
          </el-form-item>
          <el-form-item label="排名" prop="rank">
            <el-input v-model.number="formData.rank" placeholder="请输入排名"></el-input>
          </el-form-item>
          <!-- PDF上传 -->
          <el-form-item label="PDF上传" prop="pdfFile">
            <el-upload
              class="upload-pdf"
              action="/api/system/upload"  
              :on-success="handlePdfUpload"  
              :before-upload="beforePdfUpload"  
              accept=".pdf"   
              :auto-upload="true" 
            >
              <el-button type="primary" icon="Upload">选择PDF文件</el-button>
            </el-upload>
          </el-form-item>
        </template>

        <!-- 获奖模块表单 -->
        <template v-if="currentModule === 'award'">
          <el-form-item label="获奖名称" prop="name">
            <el-input v-model="formData.name" placeholder="请输入获奖名称"></el-input>
          </el-form-item>
          <el-form-item label="颁奖单位" prop="organizer">
            <el-input v-model="formData.organizer" placeholder="请输入颁奖单位"></el-input>
          </el-form-item>
          <el-form-item label="获奖时间" prop="awardTime">
            <el-date-picker v-model="formData.awardTime" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD"></el-date-picker>
          </el-form-item>
          <el-form-item label="奖励级别" prop="level">
            <el-select v-model="formData.level" placeholder="请选择">
              <el-option label="国家级" value="国家级"></el-option>
              <el-option label="省部级" value="省部级"></el-option>
              <el-option label="校级" value="校级"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="排名" prop="rank">
            <el-input v-model.number="formData.rank" placeholder="请输入排名"></el-input>
          </el-form-item>
          <!-- PDF上传 -->
          <el-form-item label="PDF上传" prop="pdfFile">
            <el-upload
              class="upload-pdf"
              action="/api/system/upload"  
              :on-success="handlePdfUpload"  
              :before-upload="beforePdfUpload"  
              accept=".pdf"   
              :auto-upload="true" 
            >
              <el-button type="primary" icon="Upload">选择PDF文件</el-button>
            </el-upload>
          </el-form-item>
        </template>

        <!-- 专利模块表单 -->
        <template v-if="currentModule === 'patent'">
          <el-form-item label="专利名称" prop="name">
            <el-input v-model="formData.name" placeholder="请输入专利名称"></el-input>
          </el-form-item>
          <el-form-item label="专利类型" prop="type">
            <el-select v-model="formData.type" placeholder="请选择">
              <el-option label="发明专利" value="发明专利"></el-option>
              <el-option label="实用新型专利" value="实用新型专利"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="申请时间" prop="applyTime">
            <el-date-picker v-model="formData.applyTime" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD"></el-date-picker>
          </el-form-item>
          <el-form-item label="授权时间" prop="authorizeTime">
            <el-date-picker v-model="formData.authorizeTime" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD"></el-date-picker>
          </el-form-item>
          <el-form-item label="排名" prop="rank">
            <el-input v-model.number="formData.rank" placeholder="请输入排名"></el-input>
          </el-form-item>
          <!-- PDF上传 -->
          <el-form-item label="PDF上传" prop="pdfFile">
            <el-upload
              class="upload-pdf"
              action="/api/system/upload"  
              :on-success="handlePdfUpload"  
              :before-upload="beforePdfUpload"  
              accept=".pdf"   
              :auto-upload="true" 
            >
              <el-button type="primary" icon="Upload">选择PDF文件</el-button>
            </el-upload>
          </el-form-item>
        </template>

        <!-- 软著模块表单 -->
        <template v-if="currentModule === 'software'">
          <el-form-item label="软著名称" prop="name">
            <el-input v-model="formData.name" placeholder="请输入软著名称"></el-input>
          </el-form-item>
          <el-form-item label="申请时间" prop="applyTime">
            <el-date-picker v-model="formData.applyTime" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD"></el-date-picker>
          </el-form-item>
          <el-form-item label="授权时间" prop="authorizeTime">
            <el-date-picker v-model="formData.authorizeTime" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD"></el-date-picker>
          </el-form-item>
          <el-form-item label="排名" prop="rank">
            <el-input v-model.number="formData.rank" placeholder="请输入排名"></el-input>
          </el-form-item>
          <!-- PDF上传 -->
          <el-form-item label="PDF上传" prop="pdfFile">
            <el-upload
              class="upload-pdf"
              action="/api/system/upload"  
              :on-success="handlePdfUpload"  
              :before-upload="beforePdfUpload"  
              accept=".pdf"   
              :auto-upload="true" 
            >
              <el-button type="primary" icon="Upload">选择PDF文件</el-button>
            </el-upload>
          </el-form-item>
        </template>
 
      </el-form>
 
      <template  v-slot:footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">提交</el-button>
      </template >
    </el-dialog>

  </div>
</template>

<script>
import { getSubjectList, addSubject, deleteSubject  } from '@/api/researchPerformance/subject.js';
import { getPaperList, addPaper, deletePaper  } from '@/api/researchPerformance/paper.js';
import { getMonographList, addMonograph, deleteMonograph  } from '@/api/researchPerformance/monograph.js';
import { getAwardList, addAward, deleteAward  } from '@/api/researchPerformance/award.js';
import { getPatentList, addPatent, deletePatent  } from '@/api/researchPerformance/patent.js';
import { getSoftwareList, addSoftware, deleteSoftware  } from '@/api/researchPerformance/software.js';
import { beforePdfUpload, handlePdfUpload } from '@/api/system/upload.js';
import { getCookie } from '@/utils/cookie.js';


export default {

  data() {
    return {
      // 新增：上传请求头配置（携带认证Token）
      uploadHeaders: {
        Authorization: 'Bearer ' + getCookie('Admin-Token')
      },

      // 课题模块
      subjectTableData: [],
      subjectTotalWorkload: 0,
      // 论文模块
      paperTableData: [],
      paperTotalWorkload: 0,
      // 论著模块
      monographTableData: [],
      monographTotalWorkload: 0,
      // 获奖模块
      awardTableData: [],
      awardTotalWorkload: 0,
      // 专利模块
      patentTableData: [],
      patentTotalWorkload: 0,
      // 软著模块
      softwareTableData: [],
      softwareTotalWorkload: 0,

      // 加载状态
      loading: {
        subject: false,
        paper: false,
        monograph: false,
        award: false,
        patent: false,
        software: false
      },   
      
      // 模块分页参数集合：key=模块标识，value=分页参数
      modulePagination: {
        subject: { currentPage: 1, pageSize: 10, total: 0 }, // 课题分页参数
        paper: { currentPage: 1, pageSize: 10, total: 0 },   // 论文分页参数
        monograph: { currentPage: 1, pageSize: 10, total: 0 }, // 论著分页参数
        award: { currentPage: 1, pageSize: 10, total: 0 },    // 获奖分页参数
        patent: { currentPage: 1, pageSize: 10, total: 0 },   // 专利分页参数
        software: { currentPage: 1, pageSize: 10, total: 0 }  // 软著分页参数
      },

      // 年度工作量汇总静态数据
      yearWorkloadTableData: [{
        year: 2024,
        subjectWorkload: 320.50,
        paperWorkload: 280.00,
        monographWorkload: 120.00,
        awardWorkload: 150.00,
        patentWorkload: 90.00,
        softwareWorkload: 40.00,
        totalWorkload: 1000.50
      }],



      // 新增：弹窗控制
      dialogVisible: false,
      currentModule: '', // 当前模块标识：subject/paper/monograph等
      dialogTitle: '',
      formData: {
        pdfUrl: ''  // 存储上传后的PDF文件URL
      }, // 新增表单数据
      formRules: {
        // 课题模块验证规则
        subject: {
          projectName: [{ required: true, message: '请输入项目名称', trigger: 'blur' }],
          subjectType: [{ required: true, message: '请选择课题类型', trigger: 'change' }],
          executeTime: [
            { required: true, message: '请选择执行时间', trigger: 'change' },
            { 
              validator: (rule, value, callback) => {
                if (value && Array.isArray(value) && value.length === 2) {
                  callback();
                } else {
                  callback(new Error('请选择完整的执行时间范围'));
                }
              }, 
              trigger: 'change' 
            }
          ],
          rank: [{ required: true, message: '请输入排名', trigger: 'blur' }],
          coefficient: [{ required: true, message: '请选择系数', trigger: 'change' }],
          pdfUrl: [{ required: true, message: '请上传PDF文件', trigger: 'change' }]

        },
        // 论文模块验证规则
        paper: {
          title: [{ required: true, message: '请输入论文名称', trigger: 'blur' }],
          journal: [{ required: true, message: '请输入刊物名称', trigger: 'blur' }],
          publishTime: [{ required: true, message: '请选择出版时间', trigger: 'change' }],
          level: [{ required: true, message: '请选择论文级别', trigger: 'change' }],
          rank: [{ required: true, message: '请输入排名', trigger: 'blur' }]
        },
        // 论著模块验证规则
        monograph: {
          title: [{ required: true, message: '请输入论著名称', trigger: 'blur' }],
          publisher: [{ required: true, message: '请输入出版社', trigger: 'blur' }],
          publishTime: [{ required: true, message: '请选择出版时间', trigger: 'change' }],
          rank: [{ required: true, message: '请输入排名', trigger: 'blur' }]
        },
        // 获奖模块验证规则
        award: {
          name: [{ required: true, message: '请输入获奖名称', trigger: 'blur' }],
          organizer: [{ required: true, message: '请输入颁奖单位', trigger: 'blur' }],
          awardTime: [{ required: true, message: '请选择获奖时间', trigger: 'change' }],
          level: [{ required: true, message: '请选择奖励级别', trigger: 'change' }],
          rank: [{ required: true, message: '请输入排名', trigger: 'blur' }]
        },
        // 专利模块验证规则
        patent: {
          name: [{ required: true, message: '请输入专利名称', trigger: 'blur' }],
          type: [{ required: true, message: '请选择专利类型', trigger: 'change' }],
          applyTime: [{ required: true, message: '请选择申请时间', trigger: 'change' }],
          authorizeTime: [{ required: true, message: '请选择授权时间', trigger: 'change' }],
          rank: [{ required: true, message: '请输入排名', trigger: 'blur' }]
        },
        // 软著模块验证规则
        software: {
          name: [{ required: true, message: '请输入软著名称', trigger: 'blur' }],
          applyTime: [{ required: true, message: '请选择申请时间', trigger: 'change' }],
          authorizeTime: [{ required: true, message: '请选择授权时间', trigger: 'change' }],
          rank: [{ required: true, message: '请输入排名', trigger: 'blur' }]
        }
      }
    };
  },

  mounted() {
    // 加载所有模块数据
    this.getSubjectData();
    this.getPaperData();
    this.getMonographData();
    this.getAwardData();
    this.getPatentData();
    this.getSoftwareData();
    // // 加载年度汇总数据
    // this.getYearWorkloadData();
  },

  methods: {
    beforePdfUpload,
    // handlePdfUpload,
    // 组件内定义上传成功回调（替换导入的handlePdfUpload）
    handlePdfUpload(response, file) {
      if (response.code === 200) {
        // 直接更新表单数据（this指向组件实例）
        this.formData.pdfUrl = response.data.url; 
        this.$message.success(`文件上传成功: ${file.name}`);
        // 手动触发表单验证，更新"pdfUrl"字段的验证状态
        this.$refs.addFormRef.validateField('pdfUrl'); 
      } else {
        this.$message.error(`上传失败: ${response.msg || '服务器错误'}`);
      }
    },
    // 课题模块数据获取方法
    getSubjectData() {
      this.getModuleData(
        'subject',          // 模块标识
        getSubjectList,     // 课题列表接口
        'subjectTableData', // 表格数据字段
        'subjectTotalWorkload', // 总工作量字段
        '课题数据加载失败'  // 错误提示
      );
    },
    // 论文模块数据获取方法
    getPaperData() { 
      this.getModuleData(
        'paper',          // 模块标识
        getPaperList,     // 论文列表接口
        'paperTableData', // 表格数据字段
        'paperTotalWorkload', // 总工作量字段
        '论文数据加载失败'  // 错误提示
      );
    },
    // 论著模块数据获取方法
    getMonographData() { 
      this.getModuleData(
        'monograph',          // 模块标识
        getMonographList,     // 专著列表接口
        'monographTableData', // 表格数据字段
        'monographTotalWorkload', // 总工作量字段
        '论著数据加载失败'  // 错误提示
      );
    },
    // 获奖模块数据获取方法
    getAwardData() { 
      this.getModuleData(
        'award',          // 模块标识
        getAwardList,     // 获奖列表接口
        'awardTableData', // 表格数据字段
        'awardTotalWorkload', // 总工作量字段
        '获奖数据加载失败'  // 错误提示
      );
    },
    // 专利模块数据获取方法
    getPatentData() { 
      this.getModuleData(
        'patent',          // 模块标识
        getPatentList,     // 专利列表接口
        'patentTableData', // 表格数据字段
        'patentTotalWorkload', // 总工作量字段
        '专利数据加载失败'  // 错误提示
      );
    },
    // 软著模块数据获取方法
    getSoftwareData() { 
      this.getModuleData(
        'software',          // 模块标识
        getSoftwareList,     // 软著列表接口
        'softwareTableData', // 表格数据字段
        'softwareTotalWorkload', // 总工作量字段
        '软著数据加载失败'  // 错误提示
      );
    },
    /**
     * 通用模块数据获取方法
     * @param {String} module - 模块标识（如 'paper'/'monograph'）
     * @param {Function} apiFunc - 模块对应的列表接口（如 getPaperList/getMonographList）
     * @param {String} tableDataKey - 表格数据存储字段（如 'paperTableData'）
     * @param {String} totalWorkloadKey - 总工作量存储字段（如 'paperTotalWorkload'）
     * @param {String} errorMsg - 加载失败提示文本
     */
    async getModuleData(module, apiFunc, tableDataKey, totalWorkloadKey, errorMsg) {
      this.loading[module] = true; // 动态设置模块加载状态
      try {
        // 获取当前模块的分页参数（独立参数，不影响其他模块）
        const { currentPage, pageSize } = this.modulePagination[module];
        // 调用接口时传递当前模块的分页参数
        const response = await apiFunc({ pageNum: currentPage, pageSize });
        
        // 更新当前模块的表格数据和总条数
        this[tableDataKey] = response.data.records;
        this.modulePagination[module].total = response.data.total; // 独立存储总条数
        this[totalWorkloadKey] = response.data.records.reduce(
          (sum, item) => sum + Number(item.workload || 0), 
          0
        );
      } catch (error) {
        this.$message.error(errorMsg); // 动态错误提示
      } finally {
        this.loading[module] = false; // 关闭加载状态
      }
    },

    // ======== 新增数据 ========
    // 新增：打开新增弹窗
    handleAdd(module) {
      this.currentModule = module;
      this.dialogTitle = `新增${this.getModuleName(module)}`;
      this.formData = this.initFormData(module); // 初始化表单数据
      this.dialogVisible = true;
    },
 
    // 新增：初始化表单数据
    initFormData(module) {
      switch (module) {
        case 'subject':
          // return { projectName: '', subjectType: '', execute_time_start: null, execute_time_end: null, rank: null, coefficient: '' };
          return { projectName: '', subjectType: '', executeTime: [], rank: null, coefficient: '' };
        case 'paper':
          return { title: '', journal: '', publishTime: '', level: '', rank: null };
        case 'monograph':
          return { title: '', publisher: '', publishTime: '', rank: null };
        case 'award':
          return { name: '', organizer: '', awardTime: '', level: '', rank: null };
        case 'patent':
          return { name: '', type: '', applyTime: '', authorizeTime: '', rank: null };
        case 'software':
          return { name: '', applyTime: '', authorizeTime: '', rank: null };
        default:
          return {};
      }
    },
 
    // 新增：获取模块名称
    getModuleName(module) {
      const map = { subject: '课题', paper: '论文', monograph: '论著', award: '获奖', patent: '专利', software: '软著' };
      return map[module] || '';
    },
 
    // 新增：提交表单到数据库
    submitForm() {
      this.$refs.addFormRef.validate(valid => {
        if (valid) {

          // 创建提交数据的副本
          let submitData = { ...this.formData };
          console.log('上传表单',submitData);

          // 1.如果是课题模块且有执行时间，进行数据转换
          if (this.currentModule === 'subject') {
            submitData.execute_time_start = submitData.executeTime[0];
            submitData.execute_time_end = submitData.executeTime[1];
            // 删除原来的executeTime字段（可选）
            delete submitData.executeTime;
          }

          // 2. 调用通用提交方法（传入当前模块名和处理后的数据）
          this.submitModuleData(this.currentModule, submitData);

        }         
      });
    },
 
    // 新增：根据模块获取接口
    getApiByModule(module) {
      const apiMap = {
        subject: addSubject,       // 课题新增接口
        paper: addPaper,           // 论文新增接口
        monograph: addMonograph,   // 论著新增接口
        award: addAward,           // 获奖新增接口
        patent: addPatent,         // 专利新增接口
        software: addSoftware      // 软著新增接口
      };
      return apiMap[module]; // 返回对应模块的接口函数
    },
 
    // 新增：刷新模块数据
    refreshModuleData(module) {
      switch (module) {
        case 'subject':
          this.getSubjectData(); // 原有获取课题数据的方法
          break;
        case 'paper':
          this.getPaperData();  // 原有获取论文数据的方法
          break;
        case 'monograph':
          this.getMonographData(); // 论著数据刷新
          break;
        case 'award':
          this.getAwardData();     // 获奖数据刷新
          break;
        case 'patent':
          this.getPatentData();    // 专利数据刷新
          break;
        case 'software':
          this.getSoftwareData();  // 软著数据刷新
          break;
      }
    },

    // 通用提交方法：适用于所有模块
    submitModuleData(module, submitData) {
      const api = this.getApiByModule(module); // 获取当前模块的接口函数
      if (!api) {
        this.$message.error("未找到模块接口");
        return;
      }
  
      api(submitData) // 调用对应模块的接口
        .then(res => {
          if (res.code === 200) {
            this.$message.success('新增成功');
            this.dialogVisible = false; // 关闭弹窗
            this.refreshModuleData(module); // 刷新当前模块数据（动态传入模块名）
          } else {
            this.$message.error(res.msg || '新增失败');
          }
        })
        .catch(() => this.$message.error('网络异常，请重试'));
    },

    // 删除数据
    handleDelete(module) {
      // 1. 首先确定模块
      const tableRef = this.$refs[`${module}TableRef`]; // 如 module='subject' → this.$refs.subjectTable
      if (!tableRef) {
        this.$message.error("未找到模块表格，请检查ref是否正确");
        return;
      }

      // 2. 获取选中的行数据（通过ref引用表格）
      const selectedRows = tableRef.getSelectionRows();
      if (selectedRows.length === 0) {
        this.$message.warning('请先选中要删除的数据行');
        return;
      }
  
      // 3. 显示确认弹窗（根据模块动态提示）
      this.$confirm(`确定删除选中的 ${selectedRows.length} 条${this.getModuleName(module)}数据吗？`, "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        // 用户点击了"确定"，执行删除逻辑
        this.executeDelete(module, selectedRows);
      }).catch(() => {
        // 用户点击了"取消"或关闭弹窗
        this.$message.info("已取消删除");
      });
    },  
    
    // 执行删除操作
    executeDelete(module, selectedRows) {
      // 根据模块调用对应后端接口
      const apiMap = {
        subject: deleteSubject,        // 课题删除接口
        paper: deletePaper,     // 论文删除接口
        monograph: deleteMonograph, // 论著删除接口
        award: deleteAward,        // 获奖删除接口
        patent: deletePatent,      // 专利删除接口
        software: deleteSoftware   // 软著删除接口
      };
      
      const deleteApi = apiMap[module];
      if (!deleteApi) {
        this.$message.error("未找到对应模块的删除接口");
        return;
      }

      // 获取要删除的ID列表
      const ids = selectedRows.map(row => row.id);
      console.log('删除的ID', ids);

      // 调用删除接口
      deleteApi(ids).then(res => {
        if (res.code === 200) {
          this.$message.success("删除成功");
          // 刷新当前模块表格数据并清空选中状态
          this.refreshModuleData(module);
          const tableRef = this.$refs[`${module}TableRef`];
          if (tableRef) {
            tableRef.clearSelection();
          }
        } else {
          this.$message.error(res.msg || "删除失败");
        }
      }).catch(error => {
        this.$message.error("网络异常，请重试");
        console.error("删除失败:", error);
      });
    },
    // 辅助方法：根据模块标识获取模块名称（如 'subject' → '课题'）
    getModuleName(module) {
      const moduleMap = { subject: "课题", paper: "论文", monograph: "论著", award: "获奖", patent: "专利", software: "软著" };
      return moduleMap[module] || "数据";
    },
  
    // 辅助方法：刷新模块数据（根据模块标识调用对应数据获取方法）
    refreshModuleData(module) {
      const refreshMap = {
        subject: this.getSubjectData, // 获取课题数据的方法
        paper: this.getPaperData,   // 获取论文数据的方法
        monograph: this.getMonographData,
        award: this.getAwardData,
        patent: this.getPatentData,
        software: this.getSoftwareData,
      };
      const refreshMethod = refreshMap[module];
      if (refreshMethod && typeof refreshMethod === "function") {
        refreshMethod(); // 调用对应模块的数据刷新方法
      }
    },

    handleLocalUpload(file) {
      
      // 模拟上传成功，生成虚拟本地URL（仅前端可见，实际文件未发送）
      const virtualUrl = `file:///C:/Users/jimmy/Desktop/pdfupload/${file.name}`; // 自定义本地路径格式
      this.formData.pdfUrl = virtualUrl; // 绑定到表单字段
      
      // 模拟后端响应，触发成功回调
      this.$message.success("本地模拟上传成功");
      this.$refs.addFormRef.validateField("pdfUrl"); // 触发表单校验
    },
    
    // 保留文件格式/大小校验（与之前逻辑一致）
    beforePdfUpload(file) {
      const isPDF = file.type === "application/pdf";
      const isLt20M = file.size / 1024 / 1024 < 20;
      if (!isPDF) this.$message.error("仅支持PDF格式");
      if (!isLt20M) this.$message.error("文件大小不超过20MB");
      return isPDF && isLt20M;
    },
    // /**
    //  * 上传前校验PDF格式和大小
    //  */
    // beforePdfUpload(file) {
    //   const isPDF = file.type === 'application/pdf';
    //   const isLt20M = file.size / 1024 / 1024 < 20;  // 限制20MB内
    //   if (!isPDF) this.$message.error('仅支持PDF格式文件');
    //   if (!isLt20M) this.$message.error('文件大小不能超过20MB');
    //   return isPDF && isLt20M;
    // },
  
    // /**
    //  * 上传成功后保存PDF URL
    //  */
    // handlePdfUpload(response) {
    //   if (response.code === 200) {
    //     this.formData.pdfUrl = response.data.url;  // 后端返回的PDF文件URL
    //     this.$message.success('PDF上传成功');
    //   } else {
    //     this.$message.error('PDF上传失败');
    //   }
    // },

     /**
     * 每页条数变化事件（独立模块版）
     * @param {String} module - 模块标识（如 'subject'/'paper'）
     * @param {Number} pageSize - 新的每页条数
     */
    handleSizeChange(module, pageSize) {
      // 更新当前模块的 pageSize，并重置页码为1
      this.modulePagination[module].pageSize = pageSize;
      this.modulePagination[module].currentPage = 1;
      // 重新加载当前模块数据
      this.refreshModuleData(module); 
    },
  
    /**
     * 页码变化事件（独立模块版）
     * @param {String} module - 模块标识
     * @param {Number} currentPage - 新的页码
     */
    handleCurrentChange(module, currentPage) {
      // 更新当前模块的页码
      this.modulePagination[module].currentPage = currentPage;
      // 重新加载当前模块数据
      this.refreshModuleData(module);
    },



  }
};
</script>

<style scoped>
.research-performance {
  padding: 20px;
  background-color: #fafafa;
}
.page-header {
  margin-bottom: 30px;
}
.main-title {
  font-size: 24px;
  color: #1f2f3d;
  font-weight: 600;
  text-align: center;
  margin-bottom: 10px;
}
.module-card {
  margin-bottom: 30px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  overflow: hidden;
}
.module-header {
  padding: 12px 20px;
  background-color: #f5f7fa;
  border-bottom: 1px solid #e6e6e6;
}

.module-title {
  font-size: 18px;
  color: #2c3e50;
  font-weight: 500;
  padding-left: 10px;
  border-left: 4px solid #409eff;
  margin: 0;
}
.module-table {
  width: 100%;
  font-size: 14px;
}
/* 表头样式 */
:deep(.el-table th) {
  background-color: #f0f2f5;
  color: #303133;
  font-weight: 500;
}

/* 表格斑马纹行 */
:deep(.el-table__row:nth-child(even)) {
  background-color: #fafafa;
}

/* 表格悬停行高亮 */
:deep(.el-table__row:hover) {
  background-color: #f5f9ff;
}

/* 单元格内边距 */
:deep(.el-table td) {
  padding: 12px 8px;
}

:deep(.module-header) {
  display: flex;
  justify-content: space-between; /* 关键：两端对齐 */
  align-items: center; /* 垂直居中 */
  padding: 12px 20px;
}

.workload-value {
  color: #2c6ecb;
  font-weight: 500;
}
/* 分页控件容器样式 */
.pagination-container {
  padding: 10px 20px;
  margin-bottom: 20px;
  text-align: center;
  width: 100%; /* 确保占满整个容器宽度 */
  box-sizing: border-box; /* 包含padding在宽度计算内 */
}

/* 调整分页控件本身的样式 */
:deep(.el-pagination) {
  display: inline-flex; /* 使用flex布局 */
  flex-wrap: wrap; /* 允许换行 */
  justify-content: center;
  margin-top: -10px;
  gap: 5px; /* 元素之间的间距 */
}


.module-summary {
  text-align: right;
  padding: 12px 20px;
  font-size: 14px;
  color: #303133;
  border-top: 1px dashed #e6e6e6;
  background-color: #fafafa;
}
.summary-label {
  color: #606266;
}
.summary-value {
  font-weight: 500;
  color: #e67700;
  margin-left: 8px;
}
.annual-workload-card {
  border-top: 3px solid #409eff;
}
.summary-table {
  font-size: 14px;
}
.total-workload {
  font-size: 16px;
  font-weight: 600;
  color: #e67700;
}
/* 上传文件提示样式 */
.uploaded-file {
  display: flex;
  align-items: center;
  margin-top: 10px;
  padding: 8px 12px;
  background: #f0f9eb;
  border-radius: 4px;
  color: #13ce66;
}
.uploaded-file .el-icon {
  margin-right: 8px;
}
.uploaded-file .el-button {
  margin-left: 10px;
  color: #ff4d4f;
}
</style>